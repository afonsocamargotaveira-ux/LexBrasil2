import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  ExternalHyperlink,
  HeadingLevel,
  AlignmentType,
  PageBreak,
} from "docx";

export const runtime = "nodejs";

const VERDE_ESCURO = "072E21";
const VERDE = "0B4A35";

function formatarDataHora(d) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`;
}

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return new Response("Corpo da requisição inválido.", { status: 400 });
  }

  const { resultados = [], paramsBusca = {} } = body || {};

  const children = [];

  // --- Capa ---
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: "LexBrasil",
          bold: true,
          size: 60, // 30pt
          color: VERDE_ESCURO,
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: "Resultado de Pesquisa de Legislação — Câmara dos Deputados",
          italics: true,
          size: 26, // 13pt
          color: VERDE,
        }),
      ],
    }),
    new Paragraph({ text: "" }),
    new Paragraph({
      children: [
        new TextRun({ text: "Abrangência: ", bold: true }),
        new TextRun(paramsBusca.abrangencia || ""),
      ],
    }),
    new Paragraph({
      children: [
        new TextRun({ text: "Termo(s) pesquisado(s): ", bold: true }),
        new TextRun(paramsBusca.termo || ""),
      ],
    })
  );

  if (paramsBusca.numero) {
    children.push(
      new Paragraph({
        children: [
          new TextRun({ text: "Número: ", bold: true }),
          new TextRun(String(paramsBusca.numero)),
        ],
      })
    );
  }
  if (paramsBusca.ano) {
    children.push(
      new Paragraph({
        children: [
          new TextRun({ text: "Ano: ", bold: true }),
          new TextRun(String(paramsBusca.ano)),
        ],
      })
    );
  }
  if (paramsBusca.tipo && paramsBusca.tipo !== "(Todos os tipos)") {
    children.push(
      new Paragraph({
        children: [
          new TextRun({ text: "Tipo de norma: ", bold: true }),
          new TextRun(paramsBusca.tipo),
        ],
      })
    );
  }

  children.push(
    new Paragraph({
      children: [
        new TextRun({ text: "Total de normas encontradas nesta exportação: ", bold: true }),
        new TextRun(String(resultados.length)),
      ],
    }),
    new Paragraph({
      children: [
        new TextRun({ text: "Data da consulta: ", bold: true }),
        new TextRun(formatarDataHora(new Date())),
      ],
    }),
    new Paragraph({ children: [new PageBreak()] })
  );

  // --- Resultados ---
  resultados.forEach((item, i) => {
    children.push(
      new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [
          new TextRun({
            text: `${i + 1}. ${item.titulo}`,
            color: VERDE_ESCURO,
          }),
        ],
      })
    );

    if (item.situacao) {
      children.push(
        new Paragraph({
          children: [
            new TextRun({ text: "Situação: ", bold: true }),
            new TextRun(item.situacao),
          ],
        })
      );
    }

    children.push(
      new Paragraph({
        children: [
          new TextRun({ text: "Ementa: ", bold: true }),
          new TextRun(item.ementa || "(ementa não disponível)"),
        ],
      }),
      new Paragraph({
        children: [
          new TextRun({ text: "Link: ", bold: true }),
          new ExternalHyperlink({
            link: item.link,
            children: [
              new TextRun({
                text: item.link,
                style: "Hyperlink",
                color: VERDE,
                underline: {},
              }),
            ],
          }),
        ],
      }),
      new Paragraph({ text: "" })
    );
  });

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: { font: "Calibri", size: 22 }, // 11pt
        },
      },
    },
    sections: [{ children }],
  });

  const buffer = await Packer.toBuffer(doc);
  const nomeArquivo = `LexBrasil_resultado_${new Date()
    .toISOString()
    .slice(0, 16)
    .replace(/[-:T]/g, "")}.docx`;

  return new Response(buffer, {
    status: 200,
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "Content-Disposition": `attachment; filename="${nomeArquivo}"`,
    },
  });
}
